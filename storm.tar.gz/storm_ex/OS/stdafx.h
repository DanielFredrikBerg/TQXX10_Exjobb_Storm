// #pragma once // GCC issues a warning when using 'pragma once' with precompiled headers...
#ifndef OS_PCH
#define OS_PCH

#include "OS.h"

#endif
