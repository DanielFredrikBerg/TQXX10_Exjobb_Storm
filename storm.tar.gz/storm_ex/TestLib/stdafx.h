// #pragma once // GCC issues a warning when using 'pragma once' with precompiled headers...
#ifndef TEST_LIB_H
#define TEST_LIB_H
#include "Shared/Storm.h"

namespace testlib {

	using namespace storm;

}

#endif
