#ifndef GC_TEST_PROJ
#define GC_TEST_PROJ

#include "Utils/Utils.h"
#include "Core/Storm.h"
#include "Gc/Config.h"
#include "Gc/Gc.h"


using namespace storm;

#endif
