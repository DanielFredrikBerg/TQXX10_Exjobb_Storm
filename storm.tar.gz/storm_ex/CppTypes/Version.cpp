#include "stdafx.h"
#include "Version.h"

Version::Version(const String &id, const String &pkg, const String &version) : id(id), pkg(pkg), version(version) {}
