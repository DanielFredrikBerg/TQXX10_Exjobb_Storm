// #pragma once // GCC issues a warning when using 'pragma once' with precompiled headers...
#ifndef CPP_TYPES_PCH
#define CPP_TYPES_PCH

#include "Utils/Utils.h"

#endif
