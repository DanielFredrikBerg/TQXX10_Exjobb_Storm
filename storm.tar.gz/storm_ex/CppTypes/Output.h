#pragma once
#include "Write.h"

// Get the GenerateMap we need.
GenerateMap genMap();

// For generating asm.
GenerateMap asmMap();
