#include "stdafx.h"
#include "Handle.h"

namespace storm {

	Handle::Handle() {}

}
