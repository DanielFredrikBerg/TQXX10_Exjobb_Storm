// #pragma once // GCC issues a warning when using 'pragma once' with precompiled headers...
#ifndef CORE_PCH
#define CORE_PCH

#include "Storm.h"

#endif
