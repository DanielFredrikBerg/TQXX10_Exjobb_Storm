#include "stdafx.h"
#include "LibData.h"

void *createLibData(storm::Engine &e) {
	return null;
}

void destroyLibData(void *data) {}
