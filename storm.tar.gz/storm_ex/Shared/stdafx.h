// #pragma once // GCC issues a warning when using 'pragma once' with precompiled headers...
#ifndef STORM_SHARED_H
#define STORM_SHARED_H

#include "Storm.h"

#endif
