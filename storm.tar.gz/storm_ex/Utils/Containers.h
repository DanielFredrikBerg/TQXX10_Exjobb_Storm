#pragma once

// Defines container types.

#include <vector>
#include <set>
#include <map>

using std::vector;
using std::map;
using std::set;

#include "Str.h"
#include "HashMap.h"
