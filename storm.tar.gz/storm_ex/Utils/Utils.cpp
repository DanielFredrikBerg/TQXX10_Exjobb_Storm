#include "stdafx.h"
#include "Platform.h"

