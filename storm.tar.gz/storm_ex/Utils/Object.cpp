#include "stdafx.h"
#include "Object.h"


NoCopy::NoCopy() {}

NoCopy::~NoCopy() {}

Singleton::Singleton() {}
