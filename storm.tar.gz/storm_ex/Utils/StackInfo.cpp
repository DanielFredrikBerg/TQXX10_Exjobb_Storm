#include "stdafx.h"
#include "StackInfo.h"
#include <typeinfo>

void StackInfo::alloc(StackFrame *frames, nat count) const {}

void StackInfo::free(StackFrame *frames, nat count) const {}

