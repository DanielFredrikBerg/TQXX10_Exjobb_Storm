#include "stdafx.h"
#include "Shared/Main.h"

SHARED_LIB_ENTRY_POINT();
