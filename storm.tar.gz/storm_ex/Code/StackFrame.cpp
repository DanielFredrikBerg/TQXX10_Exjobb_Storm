#include "stdafx.h"
#include "StackFrame.h"

namespace code {

	StackFrame::StackFrame(Nat block, Nat activation) : block(block), activation(activation) {}

}
