#pragma once

namespace code {

	/**
	 * Good utilites for debugging! Most of these are platform dependent.
	 */


	// Dump the current stack, with exception handlers and the like.
	void dumpStack();

}
