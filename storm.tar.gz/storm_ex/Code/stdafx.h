// #pragma once // GCC issues a warning when using 'pragma once' with precompiled headers...
#ifndef CODE_PCH
#define CODE_PCH

#include "Code.h"

#endif
